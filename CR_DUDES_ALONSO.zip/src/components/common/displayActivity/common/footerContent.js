import React from 'react';

function FooterContent(props) {
    return (
        <>
        {/* <div className="hr-horizontale-exercice"></div>
        <div className="footer-exercice-container">
            <a href="#" className="button button-previous">Previous</a>
            <a href="#" className="button button-continue">Continuer</a>
         </div> */}
         </>
    );
}

export default FooterContent;