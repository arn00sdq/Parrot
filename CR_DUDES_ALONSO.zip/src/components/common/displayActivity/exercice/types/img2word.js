import React from 'react';
function Img2word(props){
    return (
        <div className="syno-button-container">
            <div className="text-syno">{props.value}</div>
        </div>
    );
}

export default Img2word;