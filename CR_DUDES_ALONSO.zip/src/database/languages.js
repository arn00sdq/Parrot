import {
    flags
} from "./images";
const data = [{
        'Spanish': flags.spain,
    },
    {
        'French': flags.france
    },
    {
        'Ducth': flags.netherlands
    },
    {
        'German': flags.germany
    },
    {
        'Italian': flags.italy
    },
    {
        'Portuguese': flags.portugal
    },
    {
        'Russian': flags.russia
    },
    {
        'South-Korea': flags.south_korea
    },
    {
        'Thai': flags.thailand
    },
    {
        'English (US)': flags.united_states
    }
];

export {
    data
};