const data = Object.freeze({
    BEGINNER : "Beginner (A1-A2)",
    INTERMEDIATE : "Intermediate (B1-B2)",
    ADVANCED : "Advanced (C1-C2)"
  });
  
export {data}
