const data = Object.freeze({
  ANIMALS : "Animals",
  CLOTHING : "Clothing",
  FOOD : "Food",
  GEOGRAPHY : "Geography",
  SPORTS : "Sports",
  SCIENCE : "Science"
});

export {data};
